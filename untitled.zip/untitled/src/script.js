const devicesContent = `
  <header>
    <h1>Apple Devices History</h1>
    <nav>
      <a href="#" id="home-link">Home</a>
      <a href="#" class="active">Devices</a>
      <a href="#" id="about-link">About</a>
    </nav>
  </header>

  <main>
    <h2>Comprehensive Apple Devices Timeline</h2>
    
    <article>
      <h3>Apple I</h3>
      <p><strong>1976:</strong> The very first Apple computer, a single-board computer hand-built by Steve Wozniak.</p>
    </article>

    <article>
      <h3>Apple II</h3>
      <p><strong>1977:</strong> One of the first highly successful mass-produced microcomputers.</p>
    </article>

    <article>
      <h3>Macintosh 128K</h3>
      <p><strong>1984:</strong> First Mac with a graphical user interface and a mouse.</p>
    </article>

    <article>
      <h3>Power Macintosh</h3>
      <p><strong>1994:</strong> Apple's line of high-performance Macs using PowerPC processors.</p>
    </article>

    <article>
      <h3>iMac G3</h3>
      <p><strong>1998:</strong> Famous for its colorful translucent design and USB ports.</p>
    </article>

    <article>
      <h3>MacBook</h3>
      <p><strong>2006:</strong> The first MacBook was introduced, replacing the iBook and PowerBook lines.</p>
    </article>

    <article>
      <h3>MacBook Air</h3>
      <p><strong>2008:</strong> The world’s thinnest notebook at launch, focusing on portability.</p>
    </article>

    <article>
      <h3>MacBook Pro</h3>
      <p><strong>2006:</strong> A high-end Mac laptop aimed at professionals.</p>
    </article>

    <article>
      <h3>iPod Classic</h3>
      <p><strong>2001:</strong> The original iPod, a portable music player with a scroll wheel.</p>
    </article>

    <article>
      <h3>iPod Nano</h3>
      <p><strong>2005:</strong> A smaller, thinner iPod with a color screen.</p>
    </article>

    <article>
      <h3>iPod Shuffle</h3>
      <p><strong>2005:</strong> The smallest iPod, focused on shuffle playback without a screen.</p>
    </article>

    <article>
      <h3>iPhone</h3>
      <p><strong>2007:</strong> Apple’s revolutionary smartphone with multi-touch screen and App Store.</p>
    </article>

    <article>
      <h3>iPhone 3G / 3GS</h3>
      <p><strong>2008-2009:</strong> Added 3G connectivity and improved speed.</p>
    </article>

    <article>
      <h3>iPhone 4 / 4S</h3>
      <p><strong>2010-2011:</strong> Retina display and FaceTime video calling introduced.</p>
    </article>

    <article>
      <h3>iPhone 5 / 5S / 5C</h3>
      <p><strong>2012-2013:</strong> Taller screen and Touch ID fingerprint sensor.</p>
    </article>

    <article>
      <h3>iPhone 6 / 6 Plus</h3>
      <p><strong>2014:</strong> Larger screen sizes introduced, with Apple Pay support.</p>
    </article>

    <article>
      <h3>iPhone X</h3>
      <p><strong>2017:</strong> OLED screen, Face ID, and a design without the home button.</p>
    </article>

    <article>
      <h3>iPad (1st Gen)</h3>
      <p><strong>2010:</strong> Apple’s first tablet device, larger than an iPhone.</p>
    </article>

    <article>
      <h3>iPad 2</h3>
      <p><strong>2011:</strong> Thinner design with front and rear cameras.</p>
    </article>

    <article>
      <h3>iPad Mini</h3>
      <p><strong>2012:</strong> Smaller 7.9-inch version of the iPad.</p>
    </article>

    <article>
      <h3>iPad Pro</h3>
      <p><strong>2015:</strong> Larger, more powerful iPad designed for professionals.</p>
    </article>

    <article>
      <h3>iMac (Original)</h3>
      <p><strong>1998:</strong> All-in-one desktop with colorful translucent design.</p>
    </article>

    <article>
      <h3>iMac (Retina 5K)</h3>
      <p><strong>2014:</strong> Ultra-high resolution 5K display on iMac.</p>
    </article>

    <article>
      <h3>Mac Pro</h3>
      <p><strong>2006:</strong> Professional desktop workstation.</p>
    </article>

    <article>
      <h3>Mac Mini</h3>
      <p><strong>2005:</strong> Small, affordable desktop Mac.</p>
    </article>

    <article>
      <h3>Apple Silicon Macs</h3>
      <p><strong>2020:</strong> Macs begin using Apple-designed ARM chips for better performance and battery life.</p>
    </article>
  </main>

  <footer>
    <p>&copy; 2025 Apple History Site</p>
  </footer>
`;

const aboutContent = `
  <header>
    <h1>Apple Devices History</h1>
    <nav>
      <a href="#" id="home-link">Home</a>
      <a href="#" id="devices-link">Devices</a>
      <a href="#" class="active">About</a>
    </nav>
  </header>

  <main>
    <h2>About This Site</h2>
    <p>This website was created to showcase the rich history of Apple’s devices, highlighting key products that shaped technology.</p>
    <p>Created by your friendly web assistant.</p>
  </main>

  <footer>
    <p>&copy; 2025 Apple History Site</p>
  </footer>
`;

const homeContent = `
  <header>
    <h1>Apple Devices History</h1>
    <nav>
      <a href="#" class="active">Home</a>
      <a href="#" id="devices-link">Devices</a>
      <a href="#" id="about-link">About</a>
    </nav>
  </header>

  <main>
    <h2>Welcome to Apple Devices History</h2>
    <p>This website explores the evolution of Apple devices from the earliest models to the latest innovations.</p>

    <section>
      <h3>Timeline</h3>
      <ul>
        <li><strong>1976</strong> - Apple I</li>
        <li><strong>1984</strong> - Macintosh 128K</li>
        <li><strong>2001</strong> - iPod</li>
        <li><strong>2007</strong> - iPhone</li>
        <li><strong>2010</strong> - iPad</li>
        <li><strong>2020</strong> - Apple Silicon Macs</li>
      </ul>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 Apple History Site</p>
  </footer>
`;

// Function to update nav link "active" class
function setActiveLink(id) {
  const links = document.querySelectorAll('nav a');
  links.forEach(link => {
    if(link.id === id) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

// Handle navigation clicks and content loading
document.body.addEventListener('click', (e) => {
  if(e.target.tagName === 'A') {
    e.preventDefault();
    const id = e.target.id;

    if(id === 'devices-link') {
      document.body.innerHTML = devicesContent;
    } else if(id === 'about-link') {
      document.body.innerHTML = aboutContent;
    } else if(id === 'home-link' || e.target.classList.contains('active')) {
      document.body.innerHTML = homeContent;
    }
  }
});

// Load the home page initially
document.body.innerHTML = homeContent;